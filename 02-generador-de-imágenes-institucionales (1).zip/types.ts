
export type CameraAngle = 'original' | 'eye-level' | 'high-angle' | 'low-angle' | 'wide-shot' | 'side-view';

export interface ImageState {
  baseImage: string | null;
  personImage: string | null;
  angle: CameraAngle;
}

export interface GenerationStatus {
  loading: boolean;
  error: string | null;
  resultUrl: string | null;
  step: string;
}
