
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { CameraAngle } from "../types";

const getAngleInstruction = (angle: CameraAngle): string => {
  switch (angle) {
    case 'eye-level':
      return "Utiliza un ÁNGULO NORMAL (a la altura de los ojos), capturando la escena de forma directa y equilibrada desde una distancia considerable.";
    case 'high-angle':
      return "Utiliza un ÁNGULO PICADO (desde una posición elevada), mirando hacia abajo para mostrar la totalidad del círculo de asistentes y el espacio de trabajo.";
    case 'low-angle':
      return "Utiliza un ÁNGULO CONTRAPICADO (desde una posición baja), manteniendo la amplitud de la toma para ver todo el entorno rural.";
    case 'wide-shot':
      return "Utiliza un GRAN ANGULAR EXTREMO / PLANO GENERAL, enfatizando la magnitud del espacio comunitario y la atmósfera del lugar.";
    case 'side-view':
      return "Utiliza una PERSPECTIVA LATERAL de plano amplio, capturando la dinámica del grupo desde un costado sin acercarse a los sujetos.";
    default:
      return "Mantén la PERSPECTIVA ORIGINAL de la foto de base, asegurando un encuadre de plano general.";
  }
};

const getPrompt = (angle: CameraAngle) => `
Actúa como un fotógrafo documental profesional especializado en capacitaciones comunitarias e institucionales en salud.

INSTRUCCIONES DE GENERACIÓN:
Utiliza las dos imágenes proporcionadas como referencia:
1) Imagen de CAPACITACIÓN (Escena base).
2) Imagen de MUJER (Personaje a integrar).

Genera una NUEVA fotografía realista siguiendo estas directrices estrictas de COMPOSICIÓN ESPACIAL:

PERSPECTIVA Y ENCUADRE (CRÍTICO):
- La toma DEBE tener una PERSPECTIVA AMPLIA (Plano General o Plano General Corto).
- ${getAngleInstruction(angle)}
- LA CAPACITADORA NUNCA DEBE APARECER EN PRIMER PLANO NI DE FRENTE A LA CÁMARA DE FORMA CERCANA.
- LA CAPACITADORA DEBE ESTAR UBICADA SIEMPRE AL FONDO DE LA COMPOSICIÓN, operando desde una posición más profunda en el espacio, integrándose como parte del escenario rural.
- El enfoque debe permitir ver el contexto completo: el círculo de asistentes, el mobiliario rústico y el ambiente rural.

REEMPLAZO DEL CAPACITADOR:
- Reemplaza completamente al capacitador original por la MUJER de la imagen de referencia.
- Mantén coherencia facial absoluta, tono de piel y rasgos generales basados en la referencia.
- Actitud: Al fondo, en actitud natural de capacitación (explicando, señalando una cartelera colgante con un marcador).
- VESTIMENTA: Camiseta blanca tipo polo de dama, jeans y un CHALECO INSTITUCIONAL de color beige (sencillo, sin textos ni logotipos).

CARTELERAS Y FONDOS:
- La cartelera principal DEBE SER COLGANTE (sujeta a la pared o vigas).
- PROHIBIDO EL USO DE TRÍPODES o soportes de piso para las carteleras.
- Cualquier cartelera, pendón o superficie de fondo debe quedar COMPLETAMENTE LIMPIA y blanca/neutra. Prohibido textos o logos.

AUDIENCIA Y REALISMO:
- REEMPLAZO DE AUDIENCIA: Reemplaza niños por ADULTOS diversos.
- LENGUAJE CORPORAL: Variedad de gestos naturales (tomando apuntes, escuchando, interactuando). Sin simetrías artificiales.
- PEINADOS: Diversidad de peinados naturales en las mujeres asistentes.

ESTILO VISUAL:
- Fotografía hiperrealista documental, iluminación natural rural, colores orgánicos. Sin apariencia de render ni filtros artísticos.
`;

export const generateInstitutionalImage = async (
  baseImageBase64: string,
  personImageBase64: string,
  angle: CameraAngle
): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const cleanBaseImage = baseImageBase64.split(',')[1];
  const cleanPersonImage = personImageBase64.split(',')[1];

  const response: GenerateContentResponse = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: cleanBaseImage,
          },
        },
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: cleanPersonImage,
          },
        },
        {
          text: getPrompt(angle),
        },
      ],
    },
  });

  for (const part of response.candidates?.[0]?.content?.parts || []) {
    if (part.inlineData) {
      return `data:image/png;base64,${part.inlineData.data}`;
    }
  }

  throw new Error("No se pudo generar la imagen con la perspectiva solicitada. Intenta de nuevo.");
};
