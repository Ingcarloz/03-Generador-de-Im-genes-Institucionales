
import React, { useState } from 'react';
import { generateInstitutionalImage } from './services/geminiService';
import { ImageState, GenerationStatus, CameraAngle } from './types';

const ANGLES: { value: CameraAngle; label: string; icon: string }[] = [
  { value: 'original', label: 'Referencia Original', icon: '📸' },
  { value: 'eye-level', label: 'Ángulo Normal', icon: '👤' },
  { value: 'high-angle', label: 'Ángulo Picado', icon: '🔽' },
  { value: 'low-angle', label: 'Contrapicado', icon: '🔼' },
  { value: 'wide-shot', label: 'Gran Angular', icon: '↔️' },
  { value: 'side-view', label: 'Vista Lateral', icon: '📐' },
];

const App: React.FC = () => {
  const [images, setImages] = useState<ImageState>({
    baseImage: null,
    personImage: null,
    angle: 'original',
  });

  const [status, setStatus] = useState<GenerationStatus>({
    loading: false,
    error: null,
    resultUrl: null,
    step: 'idle',
  });

  const handleFileUpload = (type: 'baseImage' | 'personImage') => (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImages(prev => ({ ...prev, [type]: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const setAngle = (angle: CameraAngle) => {
    setImages(prev => ({ ...prev, angle }));
  };

  const handleGenerate = async () => {
    if (!images.baseImage || !images.personImage) {
      setStatus(prev => ({ ...prev, error: "Por favor sube ambas imágenes de referencia." }));
      return;
    }

    setStatus({ 
      loading: true, 
      error: null, 
      resultUrl: null, 
      step: 'Encuadrando plano amplio y procesando...' 
    });

    try {
      const result = await generateInstitutionalImage(images.baseImage, images.personImage, images.angle);
      setStatus({ 
        loading: false, 
        error: null, 
        resultUrl: result, 
        step: '¡Imagen institucional generada con éxito!' 
      });
    } catch (err: any) {
      console.error(err);
      setStatus({ 
        loading: false, 
        error: "Error de generación. Intenta con imágenes más claras.", 
        resultUrl: null, 
        step: 'error' 
      });
    }
  };

  const reset = () => {
    setImages({ baseImage: null, personImage: null, angle: 'original' });
    setStatus({ loading: false, error: null, resultUrl: null, step: 'idle' });
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-12 font-sans">
      <header className="text-center mb-12">
        <div className="inline-block px-3 py-1 mb-4 text-xs font-bold tracking-widest text-blue-600 uppercase bg-blue-100 rounded-full">
          Herramienta de Fotografía Documental
        </div>
        <h1 className="text-5xl font-black text-gray-900 mb-4 tracking-tight">
          Editor Institucional IA
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto leading-relaxed">
          Genera fotografías realistas desde diferentes ángulos, con la capacitadora siempre al fondo para un estilo documental auténtico.
        </p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 mb-12">
        {/* Panel de Entrada */}
        <div className="space-y-6">
          <div className="bg-white p-8 rounded-3xl shadow-xl shadow-gray-200/50 border border-gray-100">
            <h2 className="text-2xl font-bold mb-6 flex items-center text-gray-800">
              <span className="bg-blue-600 text-white w-8 h-8 rounded-full flex items-center justify-center mr-3 text-sm">1</span>
              Entradas de Referencia
            </h2>
            
            <div className="grid grid-cols-2 gap-4">
              {/* Imagen Base */}
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-500 uppercase">Escena Base</label>
                <div className="aspect-square bg-gray-50 border-2 border-dashed border-gray-200 rounded-2xl overflow-hidden relative group transition-all hover:border-blue-400">
                  {images.baseImage ? (
                    <img src={images.baseImage} className="w-full h-full object-cover" alt="Escena base" />
                  ) : (
                    <label className="flex flex-col items-center justify-center w-full h-full cursor-pointer p-4 text-center">
                      <svg className="w-10 h-10 text-gray-300 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                      <span className="text-xs text-gray-400 font-semibold">Subir Escena</span>
                      <input type="file" accept="image/*" className="hidden" onChange={handleFileUpload('baseImage')} />
                    </label>
                  )}
                  {images.baseImage && (
                    <button onClick={() => setImages(p => ({ ...p, baseImage: null }))} className="absolute top-2 right-2 bg-black/50 text-white p-1.5 rounded-full hover:bg-red-500">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                  )}
                </div>
              </div>

              {/* Nueva Persona */}
              <div className="space-y-2">
                <label className="text-sm font-bold text-gray-500 uppercase">Capacitadora</label>
                <div className="aspect-square bg-gray-50 border-2 border-dashed border-gray-200 rounded-2xl overflow-hidden relative group transition-all hover:border-blue-400">
                  {images.personImage ? (
                    <img src={images.personImage} className="w-full h-full object-cover" alt="Persona" />
                  ) : (
                    <label className="flex flex-col items-center justify-center w-full h-full cursor-pointer p-4 text-center">
                      <svg className="w-10 h-10 text-gray-300 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                      <span className="text-xs text-gray-400 font-semibold">Subir Persona</span>
                      <input type="file" accept="image/*" className="hidden" onChange={handleFileUpload('personImage')} />
                    </label>
                  )}
                  {images.personImage && (
                    <button onClick={() => setImages(p => ({ ...p, personImage: null }))} className="absolute top-2 right-2 bg-black/50 text-white p-1.5 rounded-full hover:bg-red-500">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white p-8 rounded-3xl shadow-xl shadow-gray-200/50 border border-gray-100">
            <h2 className="text-2xl font-bold mb-2 flex items-center text-gray-800">
              <span className="bg-blue-600 text-white w-8 h-8 rounded-full flex items-center justify-center mr-3 text-sm">2</span>
              Ángulo de Cámara
            </h2>
            <p className="text-xs text-gray-400 mb-6 flex items-center italic">
              <svg className="w-4 h-4 mr-1 text-blue-400" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd"></path></svg>
              Nota: La capacitadora se ubicará al fondo en plano amplio para mayor realismo.
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {ANGLES.map((angle) => (
                <button
                  key={angle.value}
                  onClick={() => setAngle(angle.value)}
                  className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center justify-center space-y-2 text-center ${
                    images.angle === angle.value
                      ? 'border-blue-600 bg-blue-50 text-blue-700 shadow-md'
                      : 'border-gray-100 hover:border-blue-200 hover:bg-gray-50 text-gray-500'
                  }`}
                >
                  <span className="text-2xl">{angle.icon}</span>
                  <span className="text-xs font-bold leading-tight">{angle.label}</span>
                </button>
              ))}
            </div>
          </div>

          <button
            onClick={handleGenerate}
            disabled={status.loading || !images.baseImage || !images.personImage}
            className={`w-full py-5 rounded-2xl font-black text-lg text-white shadow-2xl transition-all transform hover:scale-[1.01] active:scale-95 flex items-center justify-center space-x-3 ${
              status.loading || !images.baseImage || !images.personImage
                ? 'bg-gray-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-blue-600 to-indigo-700 hover:from-blue-700 hover:to-indigo-800'
            }`}
          >
            {status.loading ? (
              <>
                <div className="animate-spin h-6 w-6 border-4 border-white border-t-transparent rounded-full"></div>
                <span>Generando Plano Amplio...</span>
              </>
            ) : (
              <>
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
                <span>Generar Fotografía Final</span>
              </>
            )}
          </button>
        </div>

        {/* Panel de Salida */}
        <div className="flex flex-col h-full">
          <div className="bg-white p-8 rounded-3xl shadow-xl shadow-gray-200/50 border border-gray-100 flex-grow flex flex-col">
            <h2 className="text-2xl font-bold mb-6 flex items-center text-gray-800">
              <svg className="w-7 h-7 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
              Resultado Profesional
            </h2>
            
            <div className="flex-grow flex items-center justify-center bg-gray-50 rounded-2xl overflow-hidden border border-gray-200 min-h-[500px] relative">
              {status.resultUrl ? (
                <div className="w-full h-full flex flex-col items-center">
                  <img src={status.resultUrl} className="w-full h-full object-contain p-2" alt="Resultado institucional" />
                  <div className="absolute bottom-6 flex space-x-4">
                    <a 
                      href={status.resultUrl} 
                      download={`foto_institucional_${images.angle}.png`}
                      className="bg-white/90 backdrop-blur-md text-gray-900 px-6 py-3 rounded-xl shadow-2xl font-black hover:bg-white flex items-center space-x-2 border border-gray-200 transition-all hover:-translate-y-1"
                    >
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"></path></svg>
                      <span>Descargar PNG</span>
                    </a>
                  </div>
                </div>
              ) : status.loading ? (
                <div className="text-center p-12 max-w-sm">
                  <div className="mb-6 inline-block p-6 rounded-full bg-blue-50 text-blue-600 animate-pulse border border-blue-100">
                    <svg className="w-16 h-16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"></path></svg>
                  </div>
                  <h3 className="text-xl font-bold text-gray-800 mb-2">{status.step}</h3>
                  <p className="text-gray-400 font-medium text-sm">Asegurando que la capacitadora se mantenga al fondo y el plano sea lo suficientemente amplio.</p>
                </div>
              ) : status.error ? (
                <div className="text-center p-10 bg-red-50 rounded-3xl border border-red-100 mx-6">
                  <div className="bg-red-100 text-red-600 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"></path></svg>
                  </div>
                  <p className="text-red-700 font-bold mb-1">Error de Generación</p>
                  <p className="text-red-600/70 text-sm">{status.error}</p>
                  <button onClick={reset} className="mt-4 text-red-700 underline font-bold text-sm">Intentar de nuevo</button>
                </div>
              ) : (
                <div className="text-center p-12 text-gray-400 group">
                  <svg className="w-20 h-20 mx-auto mb-4 opacity-20 group-hover:opacity-30 transition-opacity" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                  <p className="text-lg font-medium">Configura el ángulo y genera</p>
                  <p className="text-sm mt-1 max-w-[250px] mx-auto italic">El sistema forzará un plano institucional amplio con la capacitadora operando desde el fondo.</p>
                </div>
              )}
            </div>
            
            {status.resultUrl && (
              <button 
                onClick={reset}
                className="mt-6 text-gray-400 hover:text-blue-600 text-sm font-bold flex items-center justify-center transition-colors uppercase tracking-widest"
              >
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"></path></svg>
                Nueva Edición
              </button>
            )}
          </div>
        </div>
      </div>

      <footer className="mt-20 border-t border-gray-100 pt-10 text-center">
        <div className="flex justify-center items-center space-x-6 mb-4">
          <span className="h-px w-12 bg-gray-200"></span>
          <p className="text-gray-400 text-sm font-medium uppercase tracking-widest">Tecnología Gemini 2.5 Flash • Perspectiva Documental</p>
          <span className="h-px w-12 bg-gray-200"></span>
        </div>
        <p className="text-gray-400 text-xs px-4 leading-relaxed max-w-3xl mx-auto">
          Esta aplicación utiliza procesamiento espacial de IA para re-interpretar el ángulo de visión de las fotografías.
          Garantiza coherencia institucional y limpieza documental en todos los planos solicitados.
        </p>
      </footer>
    </div>
  );
};

export default App;
